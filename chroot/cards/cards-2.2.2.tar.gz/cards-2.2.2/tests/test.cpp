#include <libcards.h>
int main(int argc, char** argv)
{
	Pkginfo test;
	test.run(argc,argv);
	return 0;
}
